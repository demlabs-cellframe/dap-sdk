LIBRARY_OUTPUT_NAME
-------------------

.. |XXX| replace:: :ref:`LIBRARY <Library Output Artifacts>`
.. |xxx| replace:: library
.. include:: XXX_OUTPUT_NAME.txt

See also the :prop_tgt:`LIBRARY_OUTPUT_NAME_<CONFIG>` target property.
