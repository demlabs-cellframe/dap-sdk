int foo();

int main()
{
  return foo();
}
